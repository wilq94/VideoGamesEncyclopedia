-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: videogamesencyclopediadb
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aspnetusers`
--

DROP TABLE IF EXISTS `aspnetusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aspnetusers` (
  `Id` varchar(128) NOT NULL,
  `Email` varchar(256) DEFAULT NULL,
  `EmailConfirmed` tinyint(1) NOT NULL,
  `PasswordHash` longtext,
  `SecurityStamp` longtext,
  `PhoneNumber` longtext,
  `PhoneNumberConfirmed` tinyint(1) NOT NULL,
  `TwoFactorEnabled` tinyint(1) NOT NULL,
  `LockoutEndDateUtc` datetime DEFAULT NULL,
  `LockoutEnabled` tinyint(1) NOT NULL,
  `AccessFailedCount` int(11) NOT NULL,
  `UserName` varchar(256) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aspnetusers`
--

LOCK TABLES `aspnetusers` WRITE;
/*!40000 ALTER TABLE `aspnetusers` DISABLE KEYS */;
INSERT INTO `aspnetusers` VALUES ('0bbab9ac-d795-4e29-9639-a8f5f7eed526','test2@test2.pl',0,'AMQEbc6fRn03sJVUPxkizV2vBxNG2DApYoEH05xigYCXWlbYj3WGmlJhRqyepKsc3g==','adad3972-be66-447e-8549-aeb8538cfc98',NULL,0,0,NULL,1,0,'test2'),('1b3ebd3a-d9d3-4521-b4f3-daa8dd01c8d7','paba.lech@poczta.fm',0,'','7064c72f-0f1b-40e6-9080-cf590876083f','',0,0,NULL,1,0,'paba.lech@poczta.fm'),('314b8673-f6c8-447a-b206-1ae081fd0ff4','wi1czynskipaw31@gmail.com',0,'','272df8c3-8cfa-42fa-81df-0282499895d5','',0,0,NULL,1,0,'wi1czynskipaw31@gmail.com'),('4e4725f3-3fc3-4a5f-b611-e451f2b8e474','test1@test1.pl',0,'AHLnPxw0AXClY0vl2ny8u1GD0DgK8KM/MrbzfrwBkwu9MOXB8nhmLry107jIHjnNXQ==','ccf29ecc-a782-434e-a495-64fcb50e9016',NULL,0,0,NULL,1,0,'test1'),('5c993a31-bf00-49e1-9983-68242cb02150','wilq@wilq.pl',0,'AEhidArRZD3OI6sAwtpaP5Aw8vVhC9qFqyLy2kDFHDGE7i9R1lbzBv0LPZh9Ag6ZYA==','f4da1e59-394f-40c1-b7c5-72d1a8792dbb','',0,0,NULL,1,0,'wilq@wilq.pl'),('9406f516-b244-4a8e-b1dd-c78c2104dd76','test@pawel.pl',0,'AM7GZjXffWEZO0K06VB8dVVb+Q+5IQc5gWdq4c3UGCzbLsTGPXcTljNNSD2AcwhBXg==','16ef5f51-0b71-4d04-858c-7b791587b353',NULL,0,0,NULL,1,0,'wilq'),('9a8a5ef1-77a0-463c-86e0-0ced28762573','test3@test3.pl',0,'ALBkO+CX6hqWdtqQzDEyj3OxI15imXKwVgv1ohmEHoQ/G74PNBEShJ2xyRfY8e0CuQ==','236aba7e-af39-4e95-998c-f6a1b0a76115',NULL,0,0,NULL,1,0,'test3'),('a942b7d1-d049-41e4-b480-aa118dbb9adf','test@test.pl',0,'AEhidArRZD3OI6sAwtpaP5Aw8vVhC9qFqyLy2kDFHDGE7i9R1lbzBv0LPZh9Ag6ZYA==','b765b0df-b1af-4f74-9d09-f08326b8e2ff',NULL,0,0,NULL,1,0,'test@test.pl'),('f8ccf432-880b-4233-ae06-f55405e9d9d1','pawel@pawel.pl',1,'AEhidArRZD3OI6sAwtpaP5Aw8vVhC9qFqyLy2kDFHDGE7i9R1lbzBv0LPZh9Ag6ZYA==','15038fa6-6ab8-4dda-bcf5-5400eae89d81',NULL,0,0,NULL,1,0,'pawel');
/*!40000 ALTER TABLE `aspnetusers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-30 20:30:01
