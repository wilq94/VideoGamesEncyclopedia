-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: videogamesencyclopediadb
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `Id` int(11) NOT NULL,
  `Name` varchar(45) COLLATE utf8_polish_ci NOT NULL,
  `CoverPath` varchar(45) COLLATE utf8_polish_ci DEFAULT NULL,
  `PremiereDate` datetime DEFAULT NULL,
  `CreatedBy` varchar(45) COLLATE utf8_polish_ci DEFAULT NULL,
  `Description` text COLLATE utf8_polish_ci,
  `Rating` float DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'FIFA 17','fifa17.jpg','2016-09-27 00:00:00','EA Sports','Jedną z najważniejszych marek firmy Electronic Arts od dawna jest seria FIFA, czyli symulator piłki nożnej, który przez lata zawitał na rozmaite platformy sprzętowe – od Amigi, przez smartfony, aż po najnowsze konsole. FIFA 17 na komputery osobiste jest kolejną częścią cyklu. Tym razem jednak deweloperzy nie ograniczyli się wyłącznie do kosmetycznych zmian i usprawnień rozgrywki, gdyż postanowili wdrożyć dwie ważne nowinki – grę wzbogacono o pełnoprawną kampanię fabularną, a w edycjach na komputery PC oraz konsole Xbox One i PlayStation 4 wykorzystano silnik Frostbite studia DICE, znany m.in. z serii Battlefield czy Star Wars Battlefront. Za tytuł FIFA 17 na komputery osobiste odpowiada oczywiście ekipa EA Sports, która zajmuje się także innymi sportowymi seriami firmy Electronic Arts, w tym NBA Live, NHL czy Madden NFL. Produkcja ukazała się w Polsce 29 września 2016 roku.',7.8),(2,'Wrota Baldura','wrotabaldura.jpg','1998-12-23 00:00:00','BioWare Corporation','Gdy w połowie 1998 roku zaczęły pojawiać się informacje o nowym tytule cRPG nieznanej firmy Bioware, miłośnicy tego gatunku zaczęli obserwować postępy prac z nadzieją, że gra przełamie złą passę, jaką miały od dłuższego czasu gry tego typu. I nie zawiedli się! Gra odwołuje się do korzeni cRPG ze „złotego okresu” tego gatunku w początkach lat 90, wyznaczając jednocześnie nowe standardy i redefiniując stare. Gra niemalże bezbłędnie oddaje reguły AD&D drugiej edycji. Na początku tworzymy naszego bohatera, jednak w trakcie gry mamy możliwość przyłączenia do naszego zespołu innych członków, tak, że docelowo nasza drużyna składa się z nawet 6 postaci, z których każda ma swoją osobowość, cechy i umiejętności. Baldur’s Gate to opowieść o walce dobra ze złem, przeznaczeniu, odwadze, honorze i przyjaźni. Głównym bohaterem gry jest młodzieniec, wychowywany na dworze przybranego ojca Goriona. Jednak nieznane przeznaczenie upomina się o niego, zmuszając do opuszczenia bezpiecznych murów twierdzy Candlekeep. Od tego momentu zostajemy zdani na własne siły i umiejętności, które będziemy podnosili w miarę nabywania doświadczenia. Już od samego początku możemy przyłączać do drużyny napotkane postacie, i to zarówno te o dobrym, jak i złym charakterze, z których każda opatrzona została własną biografią wplecioną w bogatą fabułę gry. Teraz czeka nas długa wyprawa prowadząca bohaterów przez wiele lokacji, prowadząca w końcu do nieuniknionej konfrontacji z ukrywającym się złem. Ogromna kraina i duża swoboda w wyborze zadań do wykonania, walka w czasie rzeczywistym z możliwością przełączenia w tryb turowy, a nade wszystko doskonała grywalność to powody, dla których tej gry nie powinno się przegapić. Atutem jest też jedno z najlepszych spolszczeń, ze znanymi polskimi aktorami podkładającymi głosy. W wydaniu Baldur’s Gate GOLD Edition zawarto dodatek Opowieści z Wybrzeża Mieczy, mousepad oraz mapę całej krainy.',8.8),(3,'Counter-Strike: Global Offensive','counterstrikeglobaloffensive.jpg','2012-08-21 00:00:00','Valve Software','Counter-Strike: Global Offensive to kolejna, po Counter-Strike: Source, próba odświeżenia tej popularnej strzelanki, która zaczynała jako modyfikacja Half-Life. Mimo upływu lat, nie zmienia się filozofia rozgrywki - nadal do czynienia mamy z drużynową grą akcji. Naprzeciw stają dwa zespoły - terroryści oraz próbujące ich powstrzymać siły specjalne. Za każdego wyeliminowanego przeciwnika nagradzani jesteśmy gotówką, za którą na początku kolejnej rundy możemy kupić lepszą broń i uzbrojenie. W grze znajdziemy cztery tryby rozgrywki: wyścig zbrojeń, demolkę, turniejowy uproszczony oraz klasyczny uproszczony. Pierwszy to wariacja klasycznego deathmatchu – po zabiciu przeciwnika dostajemy nową broń. Drugim rządzi podobna zasada w kwestii otrzymywania nowego ekwipunku, ale zabawa podzielona jest na rundy, podobnie jak w klasycznych trybach. Trzeci, jak nazwa wskazuje, przeznaczony jest dla początkujących graczy i jego zadaniem jest wprowadzenie nowicjuszy w tajniki Counter-Strike, m.in. poprzez zrezygnowanie z ognia przyjacielskiego. Tryb klasyczny turniejowy został pozbawiony wszelkich udogodnień. W CS: GO dostępne jest pięć map typu de_ (rozbrajanie/podkładanie bomby) oraz dwie cs_ (odbijanie zakładników). Każda z siedmiu plansz jest wzorowana na klasycznych polach bitew znanych z poprzednich odsłon serii. Fani na pewno rozpoznają nazwy poszczególnych aren: Dust, Dust2, Aztec, Nuke, Inferno, Italy oraz Office. Oczywiście nie obyło się bez drobnych zmian, lecz służą one jedynie polepszeniu jakości rozgrywki. Lista dostępnego uzbrojenia została rozszerzona o kilka pozycji. Osiem nowych narzędzi zniszczenia to koktajl Mołotowa, granat-przynęta, IMI Negev, Tec-9, Mag-7, Sawed-Off, PP-Bizon oraz Taser. Szczególnie ciekawy jest ten ostatni gadżet - drogi, lecz pozwalający na zabicie przeciwnika jednym celnym strzałem. Przygotowany został także odświeżony system matchmakingu, który dobiera przeciwników według posiadanych umiejętności. Poza serwerami utrzymywanymi przez Valve możemy także hostować własne rozgrywki.',8),(4,'Football Manager 2017','footballmanager2017.jpg','2016-11-04 00:00:00','Sports Interactive','Football Manager 2017 to wydana na platformę PC Windows gra sportowa należąca do kategorii określanej mianem piłkarskich menadżerów. Projekt opracowało studio Sports Interactive, czyli ten sam zespół, który stał za wszystkimi wcześniejszymi odsłonami serii. Wydawcą, również tradycyjnie, jest firma Sega.',7.9),(5,'Thomas Was Alone','thomaswasalone.jpg','2012-11-12 00:00:00','Mike Bithell','Thomas Was Alone to niezależna gra platformowa oszczędnie dawkująca środki wyrazu. Obejmujemy w niej kontrolę nad kilkoma prostokątami i poruszamy się w prawą stronę po stu poziomach pełnych niebezpieczeństw. Naszym zadaniem jest wykorzystanie umiejętności poszczególnych postaci i dotarcie do portalu znajdującego się na końcu danego etapu. Każdy z bohaterów posiada inne właściwości, które w połączeniu pozwalają na pokonanie nawet najtrudniejszych przeszkód. Przykładowo niebieski prostokąt potrafi bez problemu poruszać się po powierzchni wody, co jest niewykonalne dla pozostałych członków ekipy. Z kolei różowy, zawsze ustawiony w pozycji horyzontalnej, może podskoczyć w bardzo niewielkim stopniu, ale za to świetnie sprawdza się w roli trampoliny podbijającej wysoko towarzyszy. Pomimo minimalistycznej otoczki gra Thomas Was Alone posiada rozbudowaną ścieżkę fabularną. W związku z tym, że prostokąty posiadają uczucia, poznajemy w trakcie zabawy ich słabości, radości, smutki i plany na przyszłość. Wszystkie sekrety głównych bohaterów opowiada podczas rozgrywki narrator. Gra Thomas Was Alone powstała pierwotnie we Flashu, ale obecna wersja wykorzystuje silnik Unity Engine. W dalszym ciągu mamy jednak do czynienia z bardzo uproszczoną oprawą wizualną: wszystkie elementy poszczególnych poziomów składają się z czarnych bloków, a w tle obserwujemy stonowane grafiki. Minimalizm tej produkcji podkreśla także spokojny podkład muzyczny David Housdena pozwalający na lepsze wczucie się w opowiadaną historię.',8.8);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-30 20:30:03
